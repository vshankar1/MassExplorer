massexplorer::launchApp()
